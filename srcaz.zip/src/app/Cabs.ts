export class Cabs{
    drivername:string;
    cabtype:string;
    source:string;
    destination:string;
    fare:number;
    status:string;
    }