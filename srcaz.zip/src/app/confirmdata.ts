export class confirmData{
    pickupspot:string;
    duration: number;
    destination:string;
    fare:number;
    }