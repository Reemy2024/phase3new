export class userID{
   
    username:string;
    password:string;
    
    }