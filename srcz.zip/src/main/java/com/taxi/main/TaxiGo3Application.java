package com.taxi.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaxiGo3Application {

	public static void main(String[] args) {
		SpringApplication.run(TaxiGo3Application.class, args);
	}

}
